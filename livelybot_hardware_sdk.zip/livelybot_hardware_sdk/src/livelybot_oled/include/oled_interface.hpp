#pragma once

void oled_mission(ros::NodeHandle &n);
