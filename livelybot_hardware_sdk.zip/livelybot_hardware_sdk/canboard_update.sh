sudo chmod -R 777 /dev/tty*
source ./devel/setup.bash 
roslaunch livelybot_bringup canboard_update.launch